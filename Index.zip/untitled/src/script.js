function showSurah(id) {
  let contents = document.querySelectorAll(".content");
  contents.forEach((c) => (c.style.display = "none"));
  document.getElementById(id).style.display = "block";
}
